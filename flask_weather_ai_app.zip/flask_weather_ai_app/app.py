from flask import Flask, request, jsonify
import os
from dotenv import load_dotenv
from weather.weather import get_weather
from model import load_model, predict

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Load your AI model
model = load_model('model/rainfall-prediction-7-popular-models.pkl')

@app.route('/weather', methods=['POST'])
def fetch_weather():
    city = request.form['city']
    weather_data = get_weather(city)
    if 'error' not in weather_data:
        features = [weather_data['main']['temp'], weather_data['wind']['speed']]
        prediction = predict(model, features)
        return jsonify({
            "weather": weather_data,
            "prediction": prediction
        })
    else:
        return weather_data

if __name__ == '__main__':
    app.run(debug=True)
