import joblib

def load_model(rainfall-prediction-7-popular-models.ipynb):
    return joblib.load(rainfall-prediction-7-popular-models.ipynb)

def predict(model, features):
    return model.predict([features]).tolist()
