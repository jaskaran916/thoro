def format_weather_data(data):
    # Format the weather data as needed
    return {
        "temperature": data['main']['temp'],
        "description": data['weather'][0]['description'],
        "wind_speed": data['wind']['speed']
    }
