import requests
import os

def get_weather(city):
    api_key = os.getenv('214f1a3a1f54537701634f1b1a6bb4e1')
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": "City not found"}
