# endpoints/users.py
from fastapi import APIRouter

router = APIRouter()

@router.get("/users/")
async def read_users():
    return [{"user_id": 1, "name": "User  1"}, {"user_id": 2, "name": "User  2"}]

@router.get("/users/{user_id}")
async def read_user(user_id: int):
    return {"user_id": user_id, "name": f"User  {user_id}"}
