from fastapi import FastAPI
from endpoints import items, users

app = FastAPI()

# Include the routers
app.include_router(items.router)
app.include_router(users.router)

@app.get("/")
async def read_root():
    return {"message": "Welcome to the FastAPI application!"}
